package training.iqgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtpMicroService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
